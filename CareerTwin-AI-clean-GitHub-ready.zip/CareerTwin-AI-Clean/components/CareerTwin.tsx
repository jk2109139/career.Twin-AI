 "use client";

import { useRef, useState } from "react";
import {
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  FileText,
  Github,
  Sparkles,
  Target
} from "lucide-react";

type Skill = {
  name: string;
  current: number;
  required: number;
  gap: number;
  priority: string;
};

type RoadmapWeek = {
  week: string;
  title: string;
  tasks: string[];
};

type Project = {
  name: string;
  technologies: string[];
  impact: string;
};

type Analysis = {
  readiness: number;
  summary: string;
  detectedSkills: Skill[];
  projects: Project[];
  priorityGaps: { skill: string; reason: string }[];
  roadmap: RoadmapWeek[];
  recommendedProjects: string[];
};

const roles = [
  "Software Engineer — Fresher",
  "Frontend Developer",
  "Backend Developer",
  "AI / ML Engineer",
  "Full Stack Developer"
];

export default function CareerTwin() {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [resume, setResume] = useState<File | null>(null);
  const [github, setGithub] = useState("");
  const [role, setRole] = useState(roles[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);

  const analyze = async () => {
    setError("");

    const file = fileInputRef.current?.files?.[0];

    if (!file) {
      setError("Please upload your resume PDF first.");
      return;
    }

    if (file.type !== "application/pdf") {
      setError("Please upload a PDF resume.");
      return;
    }

    setLoading(true);

    try {
      const formData = new FormData();
      formData.append("resume", file);
      formData.append("role", role);
      formData.append("github", github);

      const response = await fetch("/api/analyze", {
        method: "POST",
        body: formData
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "AI analysis failed.");
      }

      setAnalysis(data.analysis);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while analyzing your resume."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-shell">
      <header className="topbar container">
        <div className="brand">
          <div className="brand-mark">
            <BrainCircuit size={22} />
          </div>
          <div>
            <div className="brand-title">CareerTwin AI</div>
            <div className="brand-subtitle">AI Skill-Gap Analyzer</div>
          </div>
        </div>

        <div className="badge">
          <Sparkles size={13} style={{ verticalAlign: "middle", marginRight: 5 }} />
          Gemini Powered
        </div>
      </header>

      <main>
        <section className="hero container">
          <h1>
            Build your <span>AI Career Twin</span>
          </h1>
          <p>
            Upload your resume, choose your target role, and let AI identify
            your strengths, skill gaps, job readiness, and next 30 days of
            learning.
          </p>
        </section>

        <section className="workspace container">
          <div className="card analyzer-card">
            <h2 className="section-title">Analyze your career profile</h2>
            <p className="muted">
              Gemini analyzes evidence from your resume instead of using a
              fixed demo score.
            </p>

            <div className="form-grid">
              <div className="field">
                <label className="label" htmlFor="resume">
                  Resume PDF
                </label>

                <input
                  ref={fileInputRef}
                  id="resume"
                  className="file-input"
                  type="file"
                  accept=".pdf,application/pdf"
                  onChange={(event) => {
                    setResume(event.target.files?.[0] ?? null);
                    setError("");
                    setAnalysis(null);
                  }}
                />

                <div className="help">
                  {resume ? `Selected: ${resume.name}` : "PDF only • Max 50MB"}
                </div>
              </div>

              <div className="field">
                <label className="label" htmlFor="role">
                  Target role
                </label>

                <select
                  id="role"
                  className="select"
                  value={role}
                  onChange={(event) => {
                    setRole(event.target.value);
                    setAnalysis(null);
                  }}
                >
                  {roles.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div className="field full">
                <label className="label" htmlFor="github">
                  GitHub / Portfolio URL <span className="help">(optional)</span>
                </label>

                <div style={{ position: "relative" }}>
                  <Github
                    size={17}
                    style={{
                      position: "absolute",
                      left: 14,
                      top: 15,
                      color: "#71849d"
                    }}
                  />
                  <input
                    id="github"
                    className="input"
                    style={{ paddingLeft: 42 }}
                    value={github}
                    onChange={(event) => setGithub(event.target.value)}
                    placeholder="https://github.com/yourname"
                  />
                </div>
                <div className="help">
                  Portfolio analysis can be added as the next hackathon upgrade.
                </div>
              </div>
            </div>

            <div className="actions">
              <button
                className="btn"
                onClick={analyze}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <BrainCircuit size={17} />
                    AI is analyzing your resume...
                  </>
                ) : (
                  <>
                    Analyze My Career Twin
                    <ArrowRight size={17} />
                  </>
                )}
              </button>
            </div>

            {error && <div className="error">{error}</div>}
          </div>

          {analysis && (
            <section className="results">
              <div className="card results-header">
                <div>
                  <div className="badge" style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
                    <Target size={13} />
                    {role}
                  </div>
                  <h2 style={{ margin: "14px 0 7px", fontSize: 24 }}>
                    AI Career Analysis
                  </h2>
                  <p className="muted" style={{ margin: 0, maxWidth: 700 }}>
                    {analysis.summary}
                  </p>
                </div>

                <div className="score-wrap">
                  <div
                    className="score"
                    style={{ "--score": `${analysis.readiness}%` } as React.CSSProperties}
                  >
                    <strong>{analysis.readiness}%</strong>
                  </div>
                  <div>
                    <strong>Job Readiness</strong>
                    <div className="help" style={{ marginTop: 5 }}>
                      AI estimate, not a hiring guarantee
                    </div>
                  </div>
                </div>
              </div>

              <div className="result-grid">
                <div className="card result-card">
                  <h2>Skill Gap Map</h2>

                  <div className="skill-list">
                    {analysis.detectedSkills?.length ? (
                      analysis.detectedSkills.map((skill) => (
                        <div className="skill-row" key={skill.name}>
                          <div className="skill-top">
                            <span className="skill-name">{skill.name}</span>
                            <span className="priority">{skill.priority}</span>
                          </div>

                          <div className="bar">
                            <div
                              className="bar-fill"
                              style={{ width: `${Math.min(100, Math.max(0, skill.current))}%` }}
                            />
                          </div>

                          <div className="skill-meta">
                            Current {skill.current}% • Required {skill.required}% • Gap {skill.gap}%
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="empty">No skill data returned.</div>
                    )}
                  </div>
                </div>

                <div className="card result-card">
                  <h2>Priority Skill Gaps</h2>

                  <div className="gap-list">
                    {analysis.priorityGaps?.length ? (
                      analysis.priorityGaps.map((gap) => (
                        <div className="gap-item" key={gap.skill}>
                          <strong>{gap.skill}</strong>
                          <p>{gap.reason}</p>
                        </div>
                      ))
                    ) : (
                      <div className="empty">No priority gaps returned.</div>
                    )}
                  </div>
                </div>

                <div className="card result-card">
                  <h2>30-Day AI Roadmap</h2>

                  <div className="roadmap">
                    {analysis.roadmap?.length ? (
                      analysis.roadmap.map((week) => (
                        <div className="week" key={week.week}>
                          <b>{week.week}</b>
                          <h3>{week.title}</h3>
                          <ul>
                            {week.tasks?.map((task) => (
                              <li key={task}>{task}</li>
                            ))}
                          </ul>
                        </div>
                      ))
                    ) : (
                      <div className="empty">No roadmap returned.</div>
                    )}
                  </div>
                </div>

                <div className="card result-card">
                  <h2>Recommended Projects</h2>

                  <div className="project-list">
                    {analysis.recommendedProjects?.map((project) => (
                      <div className="project" key={project}>
                        <CheckCircle2 size={16} style={{ float: "left", marginRight: 8, color: "#60a5fa" }} />
                        <strong>{project}</strong>
                      </div>
                    ))}

                    {analysis.projects?.map((project) => (
                      <div className="project" key={project.name}>
                        <strong>{project.name}</strong>
                        <p>
                          {project.technologies?.join(" • ")}
                          {project.impact ? ` — ${project.impact}` : ""}
                        </p>
                      </div>
                    ))}

                    {!analysis.recommendedProjects?.length &&
                      !analysis.projects?.length && (
                        <div className="empty">No project recommendations returned.</div>
                      )}
                  </div>
                </div>
              </div>

              <div className="card result-card">
                <h2>
                  <FileText size={18} style={{ verticalAlign: "middle", marginRight: 7 }} />
                  What CareerTwin is doing
                </h2>
                <p className="muted" style={{ marginBottom: 0 }}>
                  Resume evidence → skill extraction → target-role comparison
                  → prioritized gaps → readiness estimate → personalized
                  30-day roadmap.
                </p>
              </div>
            </section>
          )}
        </section>
      </main>
    </div>
  );
}