import { GoogleGenAI } from "@google/genai";

export const runtime = "nodejs";

const jobRequirements: Record<string, string[]> = {
  "Software Engineer — Fresher": [
    "Java",
    "Python",
    "Data Structures and Algorithms",
    "SQL",
    "Git",
    "REST APIs",
    "Object Oriented Programming",
    "Problem Solving"
  ],
  "Frontend Developer": [
    "HTML",
    "CSS",
    "JavaScript",
    "React",
    "Git",
    "REST APIs",
    "Responsive Design"
  ],
  "Backend Developer": [
    "Java",
    "Python",
    "SQL",
    "REST APIs",
    "Git",
    "Databases",
    "Authentication",
    "Backend Development"
  ],
  "AI / ML Engineer": [
    "Python",
    "Machine Learning",
    "Deep Learning",
    "NumPy",
    "Pandas",
    "SQL",
    "Statistics",
    "Git"
  ],
  "Full Stack Developer": [
    "HTML",
    "CSS",
    "JavaScript",
    "React",
    "Node.js",
    "REST APIs",
    "SQL",
    "Git"
  ]
};

export async function POST(request: Request) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return Response.json(
        { error: "GEMINI_API_KEY is missing. Put it in .env.local beside package.json." },
        { status: 500 }
      );
    }

    const formData = await request.formData();
    const file = formData.get("resume");
    const role = String(formData.get("role") || "Software Engineer — Fresher");

    if (!(file instanceof File)) {
      return Response.json({ error: "Please upload a resume PDF." }, { status: 400 });
    }

    if (file.type !== "application/pdf") {
      return Response.json({ error: "Please upload your resume as a PDF." }, { status: 400 });
    }

    if (file.size > 50 * 1024 * 1024) {
      return Response.json({ error: "Resume must be smaller than 50MB." }, { status: 400 });
    }

    const requirements =
      jobRequirements[role] ?? jobRequirements["Software Engineer — Fresher"];

    const ai = new GoogleGenAI({ apiKey });
    const buffer = Buffer.from(await file.arrayBuffer());

    const prompt = `
You are CareerTwin AI, an expert career and recruitment analyst.

Analyze the uploaded student's resume for this target role:

TARGET ROLE:
${role}

ROLE SKILLS TO COMPARE AGAINST:
${requirements.join(", ")}

Tasks:
1. Extract only technical skills supported by resume evidence.
2. Identify projects and technologies explicitly supported by the resume.
3. Compare the student's profile with the target role.
4. Identify weak or missing skills.
5. Prioritize important gaps.
6. Estimate job readiness from 0 to 100. This is an AI estimate, not a hiring guarantee.
7. Create a practical 30-day roadmap.
8. Recommend projects that would improve the student's profile.

Do not invent experience, skills, projects, certifications, or achievements.

Return ONLY valid JSON with exactly this shape:
{
  "readiness": 0,
  "summary": "short explanation",
  "detectedSkills": [
    {
      "name": "skill",
      "current": 0,
      "required": 0,
      "gap": 0,
      "priority": "High"
    }
  ],
  "projects": [
    {
      "name": "project",
      "technologies": ["technology"],
      "impact": "short explanation"
    }
  ],
  "priorityGaps": [
    {
      "skill": "skill",
      "reason": "why this matters"
    }
  ],
  "roadmap": [
    {
      "week": "Week 1",
      "title": "title",
      "tasks": ["task 1", "task 2", "task 3"]
    }
  ],
  "recommendedProjects": [
    "project idea 1",
    "project idea 2"
  ]
}

Rules:
- current, required, gap and readiness are numbers from 0 to 100.
- gap = max(required - current, 0).
- Keep the answer concise and student-friendly.
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { text: prompt },
        {
          inlineData: {
            mimeType: "application/pdf",
            data: buffer.toString("base64")
          }
        }
      ],
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text?.trim();

    if (!text) {
      throw new Error("Gemini returned an empty response.");
    }

    const analysis = JSON.parse(text);

    return Response.json({
      success: true,
      role,
      analysis
    });
  } catch (error) {
    console.error("CareerTwin AI error:", error);

    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "AI analysis failed."
      },
      { status: 500 }
    );
  }
}