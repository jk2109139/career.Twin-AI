import CareerTwin from "@/components/CareerTwin";

export default function Home() {
  return <CareerTwin />;
}