import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CareerTwin AI",
  description: "AI-powered skill-gap and career readiness analyzer"
};

export default function RootLayout({
  children
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}