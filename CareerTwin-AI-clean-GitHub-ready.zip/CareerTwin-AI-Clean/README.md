# CareerTwin AI

AI Skill-Gap Analyzer for students.

## Setup

1. Open this folder in VS Code.
2. Open PowerShell in this folder.
3. Install packages:

```powershell
npm install
```

4. Create `.env.local` beside `package.json`:

```env
GEMINI_API_KEY=YOUR_NEW_GEMINI_API_KEY
```

5. Start:

```powershell
npm run dev
```

6. Open http://localhost:3000

## Important

- Upload PDF resumes for the current MVP.
- Never expose or commit the Gemini API key.
- The Gemini key must be in `.env.local`, at the project root, beside `package.json`.
